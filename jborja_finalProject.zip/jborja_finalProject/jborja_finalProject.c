#include <avr/io.h>
#include <util/delay.h>
#define F_CPU 8000000UL
#include "io.c"
#include "io.h"

//Scale up and down
const long Scale[] = 
{	
	c4, 8, d4, 8, e4, 8, f4, 8, g4, 8, a4, 8, h4, 8, c5, 8,
	c5, 8, h4, 8, a4, 8, g4, 8, f4, 8, e4, 8, d4, 8, c4, 8, STOP_MUSIC
};

//Happy Birthday
const long Happy_bday[] = 
{
	c4, 4, c4, 4, d4, 8, c4, 8, f4, 8, e4, 10,
	c4, 4, c4, 4, d4, 8, c4, 8, g4, 8, f4, 10,
	c4, 4, c4, 4, c5, 4, a4, 8, f4, 8, e4, 8,
	d4, 8, b4b, 4, b4b, 4, a4, 8, f4, 8, g4, 8, f4, 12, STOP_MUSIC
};

// Fur Elise  
const long Fur_Elise[] = 
{
    e4, 8, d4x, 8, e4, 8, d4x, 8, e4, 8, b3, 8, d4, 8, c4, 8, a3,8, p, 8,
    c3, 8, e3, 8, a3, 8,  b3, 4, p, 8, e3, 8, g3x, 8, b3, 8, c4, 4, p, 8, e3, 8,
    e3, 8, d4x, 8, e4, 8, d4x, 8, e4, 8, b3, 8, d4, 8, c4, 8, a3, 8, p, 8, c3, 8,
    e3, 8, a3, 8, b3, 4, p, 8, e3, 8, c4, 8, b3, 8, a3, 4, STOP_MUSIC
};
		
		enum SM_songs{S_INIT, S_IDLE, S_INC, S_DEC, S_TRAV, S_PLAY}SM_song;
void tick()
{
	A = ~PINA & 0x0F;
	switch(SM_song)
	{				//transitions
		case S_INIT:
		{
			SM_song = S_IDLE;
			LCD_DisplayString(1, "     Welcome     Press A0 or A1   ");
			break;
		}
		case S_IDLE:
		{
			if (A == 0x01 || A == 0x02) //either A0 or A1 will break out of idle state
			{
				SM_song = S_TRAV;
			}
			break;
		}
		
		case S_INC:
		{
			if(A == 0x00)
			{
				SM_song = S_TRAV;
			}
			break;
		}
		
		case S_DEC:
		{
			if(A == 0x00)
			{
				SM_song = S_TRAV;
			}
			break;
		}
		
		
		case S_TRAV:
		{
			//if (A == 0x00)
			//{
			if(songNum == 0)
			{
				LCD_DisplayString(1, "      Scale                                  ");
			}
			else if (songNum == 1)
			{
				LCD_DisplayString(1, "Happy Birthday                  ");
			}
			else if (songNum == 2)
			{
				LCD_DisplayString(1, "    Fur Elise                               ");
			}
				
			//}
			if (A == 0x01 && songNum < 2) //traverses to the right and if number of songs is less than three
			{
				songNum++;
				SM_song = S_INC;
			}
			else if (A == 0x02 && songNum > 0) //traverses to the left and if number of songs greater than zero
			{
				songNum--;
				SM_song = S_DEC;
			}
			else if (A == 0x04) //go to main menu
			{
				SM_song = S_INIT;
			}
			else if (A == 0x08) //play the song 
			{
				SM_song = S_PLAY;
			}
			break;
		}
		
		case S_PLAY:
		{
			if (A == 0x04) //go to main menu 
			{
				SM_song = S_INIT;
			}
			break;
		}
	}
	
	//State actions
	switch(SM_song)
	{
		case S_INIT:
		break;
		
		case S_IDLE:
		{
			songNum = 0;
			break;
		}
		
		case S_INC:
		{
// 			if (songNum < 2)
// 			{
// 				songNum++;
// 			}
			break;
		}
		
		case S_DEC:
		{
// 			if (songNum > 0)
// 			{
// 				songNum--;
// 			}
 			break;
		}
		
		case S_TRAV:
		{
			break;
		}
		
		case S_PLAY:
		{
			if(songNum == 0 && A != 0x04)
			{
				MusicFct( Scale, 40 );
				_delay_ms(1000);
			}
			else if(songNum == 1 && A != 0x04)
			{
				MusicFct(Happy_bday, 30);
				_delay_ms(1000);
			}
			else if (songNum == 2 && A != 0x04)
			{
				MusicFct(Fur_Elise, 20 );
				_delay_ms(1000);
			}
			break;
		}
	}		
}


int main()
{
	DDRA = 0x00; PORTA = 0xFF; //button inputs
	DDRC = 0xFF; PORTC = 0x00; //LCD Data Lines ...output
	DDRD = 0xFF; PORTD = 0x00; //LCD Control Lines...output 
	InitPWM(); 
	LCD_init();
	//TimerSet(200);
	//TimerOn();

	while(1)
	{
		tick();
		//while (!TimerFlag);
		//TimerFlag = 0;
	}

}
