#ifndef __io_h__
#define __io_h__
/*//////////////////////////////////////////////////////LCD Functions////////////////////////////////////////////////////////////*/
void LCD_init();
void LCD_ClearScreen(void);
void LCD_WriteCommand (unsigned char Command);
void LCD_Cursor (unsigned char column);
void LCD_DisplayString(unsigned char column ,const unsigned char *string);
void delay_ms(int miliSec);

/*//////////////////////////////////////////////////////Timer Functions////////////////////////////////////////////////////////////*/
void TimerOn();
void TimerOff();
void TimerISR();
void TimerSet(unsigned long M);

/*//////////////////////////////////////////////////////PWM Functions////////////////////////////////////////////////////////////*/
void InitPWM();
void MusicFct( const long* Music_Notes/** handles music notes */ , uint8_t tempo /** handles the duration/span*/ );
#endif

